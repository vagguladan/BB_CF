#include "BBResources.h"

namespace BB
{
	std::map<std::wstring, Resource*> Resources::mResources = {};
}