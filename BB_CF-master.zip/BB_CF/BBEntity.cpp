#include "BBEntity.h"

namespace BB
{


	Entity::Entity()
		:mName(L"")
	{
	}

	Entity::~Entity()
	{
	}
}
