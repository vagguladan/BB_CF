#include "BBEnemy.h"
#include "BBTransform.h"
#include "BBInput.h"
#include "BBTime.h"
#include "BBAnimator.h"

namespace BB
{

	Enemy::Enemy()
	{
	}

	Enemy::~Enemy()
	{
	}

	void Enemy::Initialize()
	{
	}

	void Enemy::Update()
	{
		GameObject::Update();

		Transform* tr = GetComponent<Transform>();
		Vector2 pos = tr->GetPosition();
		Animator* anim = GetComponent<Animator>();

		if (Input::GetKey(eKeyCode::Up))
		{
			pos.y -= 300.0f * Time::DeltaTime();
		}


		if (Input::GetKey(eKeyCode::Left))
		{
			pos.x -= 300.0f * Time::DeltaTime();
		}
		if (Input::GetKeyDown(eKeyCode::Left))
			anim->PlayAnimation(L"BackMoveE", true);
		if (Input::GetKeyUp(eKeyCode::Left))
			anim->PlayAnimation(L"Enemy", true);
		

		if (Input::GetKey(eKeyCode::Down))
		{
			if (pos.y < 480.0f)
			pos.y += 300.0f * Time::DeltaTime();
		}
		if (Input::GetKeyDown(eKeyCode::Down))
			anim->PlayAnimation(L"DownMoveE", true);
		if (Input::GetKeyUp(eKeyCode::Down))
			anim->PlayAnimation(L"Enemy", true);

		if (Input::GetKey(eKeyCode::Right))
		{
			
			pos.x += 300.0f * Time::DeltaTime();
		}
		if (Input::GetKeyDown(eKeyCode::Right))
			anim->PlayAnimation(L"FrontMoveE", true);
		if (Input::GetKeyUp(eKeyCode::Right))
			anim->PlayAnimation(L"Enemy", true);

		


		tr->SetPosition(pos);
	}

	void Enemy::Render(HDC hdc)
	{
		GameObject::Render(hdc);
	}

}