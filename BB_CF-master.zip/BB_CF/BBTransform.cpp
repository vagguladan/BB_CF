#include "BBTransform.h"
#include "BBInput.h"
#include "BBTime.h"


namespace BB
{


	Transform::Transform()
		:Component(eComponentType::Transform)
	{
	}

	Transform::~Transform()
	{
	}

	void Transform::Initialize()
	{
	}

	void Transform::Update()
	{
	}

	void Transform::Render(HDC hdc)
	{
		//Rectangle(hdc,
		//	mPosition.x-210, mPosition.y-10,
		//	mPosition.x-0, mPosition.y);


	}
}