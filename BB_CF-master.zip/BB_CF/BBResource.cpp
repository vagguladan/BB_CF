#include "BBResource.h"

namespace BB
{


	Resource::Resource()
	{
	}

	Resource::~Resource()
	{
	}
}