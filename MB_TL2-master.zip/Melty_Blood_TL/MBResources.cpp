#include "MBResources.h"

namespace MB
{
	std::map<std::wstring, Resource*> Resources::_mResources = {};
}