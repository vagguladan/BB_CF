#include "MBEntity.h"

namespace MB
{
	Entity::Entity():
		mName(L"")
	{
	}
	Entity::~Entity()
	{
	}
	void Entity::Initialize()
	{
	}
	void Entity::Update()
	{
	}
	void Entity::Redner(HDC hdc)
	{
	}
}