#include "MBResource.h"

namespace MB
{
	Resource::Resource()
	{
	}
	Resource::~Resource()
	{
	}
}